function showSection(id){
 document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
 document.getElementById(id).classList.add('active');
}
function createTask(){ let v=document.getElementById("taskInput").value;if(!v)return;addTask(v);document.getElementById("taskInput").value=""; }
auth.onAuthStateChanged(u=>{ if(u) loadTasksRealtime(); });
function loadTasksRealtime(){ getTasks(t=>{ let l=document.getElementById("taskList");l.innerHTML="";t.forEach(x=>{ let li=document.createElement("li");li.textContent=x.text; let b=document.createElement("button");b.textContent="Excluir";b.classList.add("del-btn");b.onclick=()=>deleteTask(x.id); li.appendChild(b); l.appendChild(li);});}); }
function saveUserNotes(){ saveNotes(document.getElementById("notesArea").value); }
auth.onAuthStateChanged(u=>{ if(u) loadUserNotes(); });
function loadUserNotes(){ loadNotes(t=>{ document.getElementById("notesArea").value=t; }); }
function createShopItem(){ let v=document.getElementById("shopInput").value;if(!v)return;addShopItem(v);document.getElementById("shopInput").value=""; }
auth.onAuthStateChanged(u=>{ if(u) loadShopRealtime(); });
function loadShopRealtime(){ getShopItems(it=>{ let l=document.getElementById("shopList");l.innerHTML="";it.forEach(x=>{ let li=document.createElement("li");li.textContent=x.text; let b=document.createElement("button");b.textContent="Excluir";b.classList.add("del-btn");b.onclick=()=>deleteShopItem(x.id); li.appendChild(b); l.appendChild(li);});}); }
function createLink(){ let n=document.getElementById("linkName").value; let u=document.getElementById("linkUrl").value; if(!n||!u)return; addLink(n,u); document.getElementById("linkName").value=""; document.getElementById("linkUrl").value=""; }
auth.onAuthStateChanged(u=>{ if(u) loadLinksRealtime(); });
function loadLinksRealtime(){ getLinks(it=>{ let l=document.getElementById("linkList");l.innerHTML="";it.forEach(x=>{ let li=document.createElement("li");li.innerHTML=`<a href='${x.url}' target='_blank'>${x.name}</a>`; let b=document.createElement("button");b.textContent="Excluir";b.classList.add("del-btn");b.onclick=()=>deleteLink(x.id); li.appendChild(b); l.appendChild(li);});}); }
function createEvent(){ let t=document.getElementById("eventText").value; let d=document.getElementById("eventDate").value; if(!t||!d)return; addEvent(t,d); document.getElementById("eventText").value=""; document.getElementById("eventDate").value=""; }
auth.onAuthStateChanged(u=>{ if(u) loadEventsRealtime(); });
function loadEventsRealtime(){ getEvents(it=>{ let l=document.getElementById("eventList");l.innerHTML="";it.forEach(x=>{ let li=document.createElement("li");li.textContent=`${x.date} — ${x.text}`; let b=document.createElement("button");b.textContent="Excluir";b.classList.add("del-btn");b.onclick=()=>deleteEvent(x.id); li.appendChild(b); l.appendChild(li);});}); }
