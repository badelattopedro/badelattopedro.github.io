function getUID(){ return auth.currentUser ? auth.currentUser.uid : null; }
function addTask(text){ return db.collection("users").doc(getUID()).collection("tasks").add({text,createdAt:Date.now()}); }
function getTasks(cb){ db.collection("users").doc(getUID()).collection("tasks").orderBy("createdAt").onSnapshot(s=>{let r=[];s.forEach(d=>r.push({id:d.id,...d.data()}));cb(r);}); }
function deleteTask(id){ return db.collection("users").doc(getUID()).collection("tasks").doc(id).delete(); }
function saveNotes(text){ return db.collection("users").doc(getUID()).collection("notes").doc("content").set({text}); }
function loadNotes(cb){ db.collection("users").doc(getUID()).collection("notes").doc("content").onSnapshot(d=>cb(d.exists?d.data().text:"")); }
function addShopItem(text){ return db.collection("users").doc(getUID()).collection("shopping").add({text,createdAt:Date.now()}); }
function getShopItems(cb){ db.collection("users").doc(getUID()).collection("shopping").orderBy("createdAt").onSnapshot(s=>{let r=[];s.forEach(d=>r.push({id:d.id,...d.data()}));cb(r);}); }
function deleteShopItem(id){ return db.collection("users").doc(getUID()).collection("shopping").doc(id).delete(); }
function addLink(name,url){ return db.collection("users").doc(getUID()).collection("links").add({name,url,createdAt:Date.now()}); }
function getLinks(cb){ db.collection("users").doc(getUID()).collection("links").orderBy("createdAt").onSnapshot(s=>{let r=[];s.forEach(d=>r.push({id:d.id,...d.data()}));cb(r);}); }
function deleteLink(id){ return db.collection("users").doc(getUID()).collection("links").doc(id).delete(); }
function addEvent(text,date){ return db.collection("users").doc(getUID()).collection("events").add({text,date,createdAt:Date.now()}); }
function getEvents(cb){ db.collection("users").doc(getUID()).collection("events").orderBy("createdAt").onSnapshot(s=>{let r=[];s.forEach(d=>r.push({id:d.id,...d.data()}));cb(r);}); }
function deleteEvent(id){ return db.collection("users").doc(getUID()).collection("events").doc(id).delete(); }
